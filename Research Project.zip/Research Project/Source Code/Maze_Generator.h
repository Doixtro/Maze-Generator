
#pragma once
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
class Maze_Generator
{
public:
	Maze_Generator();
	~Maze_Generator();
	void Map_Initializer();//initializes the map with '?' in every spot.
	void Print_Map();//Prints the map on the screen.
	void Set_Space(int,int);
	void Make_Wall(int,int);
	void Save_Map(int);
	void Save_Map1(int);
	void Set_Height(int);
	void Set_Width(int);
	void Delete_Maps();
	void Make_Room(int,int,int,int);
	float Get_Radn();
	int Check_in_room(int,int,int);
	bool Scan(int, int);
	int fct = 0;
	int map_height=40, map_width=40;
	char map[100][100];
	int frontier[10000][2];
	float Octile(float, float,float,float);
	float Max(float, float);
	float Min(float, float);
	void A_Star(int, int, int,int, int, int, int, int, int);
	bool Valid_Pos(int, int);
};


