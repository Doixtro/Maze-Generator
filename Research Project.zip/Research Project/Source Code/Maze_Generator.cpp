
#include "Maze_Generator.h"
#include <iostream>
#include <algorithm>
#include <time.h>
#include <random>
#include <stdio.h>
#include <string>
using std::cout;
using std::endl;
char global_room_counter = 'A';
int global_rooms = 0;
int arrptr = 1;


struct ElementNode {
	int    x;//row variable
	int    y;//column variable
	float gx = 99999.0f;//giving infinite weight
	float hx = 0.0f;
	float cost = 0.0f;
	int isonclosedlist = 0;//1 for yes 0 for no.
	int isonopenlist = 0;
	int parent_x;
	int parent_y;
};

ElementNode a_star_map[100][100],z;
ElementNode arr[10000];

struct Room_Info {
	char room;
	int x;
	int y;
	int found = 0;//by default it is set to not found.
};

Room_Info Room_Array[100];


Maze_Generator::Maze_Generator()
{
	memset(map, 0, sizeof(map));
}


Maze_Generator::~Maze_Generator()
{
}

void Maze_Generator::Map_Initializer()
{
	memset(map, 0, sizeof(map));//reset the map
	int i, j;
	for (i = 0; i < map_height; ++i)
	{
		for (j = 0; j < map_width; ++j)
		{
			map[i][j] = '?';//we do not know if it is a wall or a corridor yet.
		}
	}

}

void Maze_Generator::Print_Map()
{
	int i, j, k;
	int left = 0, right = 0, left_found = 0;
	for (i = 0; i < map_height; ++i)
	{
		for (j = 0; j < map_width; ++j)
		{
			if (map[i][j] == '.')
			{
				map[i][j] = ' ';
			}
			cout << map[i][j] << " ";
		}
		cout << endl;
	}
}

void Maze_Generator::Set_Space(int x, int y)
{

	int extra[4][2] = { 0 };

	int pointer, element_exist = 0;
	map[x][y] = '.';//. is representing a space.
	if (y > 0)
	{
		if (map[x][y - 1] == '?')
		{
			map[x][y - 1] = ',';//it has been explored but not set yet.
			extra[element_exist][0] = x;//figure out append.
			extra[element_exist][1] = y - 1;//figure out append.

			++element_exist;
		}
	}
	if (y < map_width - 1)
	{
		if (map[x][y + 1] == '?')
		{
			map[x][y + 1] = ',';//it has been explored but not set yet.
			extra[element_exist][0] = x;//figure out append.
			extra[element_exist][1] = y + 1;//figure out append.
			++element_exist;
		}
	}
	if (x > 0)
	{
		if (map[x - 1][y] == '?')
		{
			map[x - 1][y] = ',';//it has been explored but not set yet.
			extra[element_exist][0] = x - 1;//figure out append.
			extra[element_exist][1] = y;//figure out append.
			++element_exist;
		}
	}
	if (x < map_height - 1)
	{
		if (map[x + 1][y] == '?')
		{
			map[x + 1][y] = ',';//it has been explored but not set yet.
			extra[element_exist][0] = x + 1;//figure out append.
			extra[element_exist][1] = y;//figure out append.
			++element_exist;
		}
	}
	/*
	for (int l = 0; l < element_exist; ++l)
	{
		cout << extra[l][0] << "," << extra[l][1] << endl;
	}
	*/
	/*
	case 1: no elements. Do not do anything.

	case 2: 1 element, copy as it is.

	case 3: random shuffle.
	for(i=0;i<element_exist;i++)

	*/
	if (element_exist == 1)
	{

		frontier[fct][0] = extra[element_exist - 1][0];
		frontier[fct][1] = extra[element_exist - 1][1];//global frontier pointer
		++fct;
	}

	if (element_exist > 1)
	{

		srand(time(0));
		char temp1, temp2;
		int r = std::rand() % element_exist;//random number between 0 to element_exist


		for (int i = 0; i < element_exist; ++i)
		{
			temp1 = extra[i][1];
			extra[i][1] = extra[r][1];
			extra[r][1] = temp1;

			temp2 = extra[i][0];
			extra[i][0] = extra[r][0];
			extra[r][0] = temp2;
		}

		for (int i = 0; i < element_exist; ++i)
		{
			frontier[fct][1] = extra[i][1];
			frontier[fct][0] = extra[i][0];
			++fct;
		}
	}

}
void Maze_Generator::Make_Wall(int x, int y)
{
	map[x][y] = '#';
}

float Maze_Generator::Get_Radn()
{
	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<> dis(1, RAND_MAX);
	return dis(gen);
}

bool Maze_Generator::Scan(int x, int y)//return true if space can be made otherwise make wall and return false
{
	int edgestate = 0;
	if (y > 0)
	{
		if (map[x][y - 1] == '.')
		{
			edgestate += 1;
		}
	}
	if (y < map_width - 1)
	{
		if (map[x][y + 1] == '.')
		{
			edgestate += 2;
		}
	}
	if (x > 0)
	{
		if (map[x - 1][y] == '.')
		{
			edgestate += 4;
		}
	}
	if (x < map_height - 1)
	{
		if (map[x + 1][y] == '.')
		{
			edgestate += 8;
		}
	}
	//return true;
	switch (edgestate)
	{
	case 1:
		if (y < map_width - 1)
		{
			if (x > 0)
			{
				if (map[x - 1][y + 1] == '.')
					return false;
			}
			if (x < map_height - 1)
			{
				if (map[x + 1][y + 1] == '.')
					return false;
			}
			return true;
		}
		break;

	case 2:
		if (y > 0)
		{
			if (x > 0)
			{
				if (map[x - 1][y - 1] == '.')
					return false;
			}
			if (x < map_height - 1)
			{
				if (map[x + 1][y - 1] == '.')
					return false;
			}
			return true;
		}
		break;
	case 4:
		if (x < map_height - 1)
		{
			if (y > 0)
			{
				if (map[x + 1][y - 1] == '.')
					return false;
			}
			if (y < map_width - 1)
			{
				if (map[x + 1][y + 1] == '.')
					return false;
			}
			return true;
		}
		break;
	case 8:
		if (x > 0)
		{
			if (y > 0)
			{
				if (map[x - 1][y - 1] == '.')
					return false;
			}
			if (y < map_width - 1)
			{
				if (map[x - 1][y + 1] == '.')
					return false;
			}
			return true;
		}
		return false;
		break;
	}
	return false;
}
float Maze_Generator::Max(float a, float b)
{
	if (a > b)
		return a;
	else
		return b;
}

float Maze_Generator::Min(float a, float b)
{
	if (a < b)
		return a;
	else
		return b;
}
float Maze_Generator::Octile(float x, float y, float des_x, float des_y)
{

	float cal_x = 0.0f, cal_y = 0.0f, octile = 0.0f;
	cal_x = abs(x - des_x);//finding the distance btw x coordinates
	cal_y = abs(y - des_y);//finding the distance btw y coordinates
	octile = Min(cal_x, cal_y)*sqrt(2.0f) + Max(cal_x, cal_y) - Min(cal_x, cal_y);
	return octile;

}
void Maze_Generator::Save_Map(int mp)
{
	std::string ctr = ".txt";
	std::string filepath = "../Maps/Map" + std::to_string(mp) + ctr;
	FILE *fp = fopen(filepath.c_str(), "w");

	int i, j;
	fprintf(fp, "[\n");
	for (i = map_height - 1; i >= 0; --i)
	{
		fprintf(fp, "[\n");
		for (j = 0; j < map_width; ++j)
		{
			if (j != map_width - 1)
			{
				if (map[i][j] == '#')
				{

					fprintf(fp, "true,\n");
				}
				else
				{

					fprintf(fp, "false,\n");
				}
			}
			else
			{
				if (map[i][j] == '#')
				{

					fprintf(fp, "true\n");
				}
				else
				{

					fprintf(fp, "false\n");
				}
			}
		}
		if (i != 0)
		{
			fprintf(fp, "],\n");
		}
		else
		{
			fprintf(fp, "]");
		}
	}
	fprintf(fp, "]\n");
	fclose(fp);

}
void Maze_Generator::Save_Map1(int mp)
{
	std::string ctr = ".txt";
	std::string filepath = "../Mapp/Map" + std::to_string(mp) + ctr;
	FILE *fp = fopen(filepath.c_str(), "w");

	int i, j;
	for (i = map_height-1;i>=0;--i)
	{
		for (j = 0; j < map_width; ++j)
		{			
			if (map[i][j] == '#')
			{
				fprintf(fp, "0\n");
			}
			if (map[i][j] == ' ')
			{
				fprintf(fp, "1\n");
			}
			if (map[i][j] == '@')
			{
				fprintf(fp, "2\n");
			}
			if (map[i][j] >= 'A'&& map[i][j] <= '~')
			{
				fprintf(fp, "2\n");
			}
			if (map[i][j] == '?')
			{
				fprintf(fp, "3\n");
			}
			if (map[i][j] == '~')
			{
				fprintf(fp, "4\n");
			}
			
		}
	}
	fclose(fp);

}
void Maze_Generator::Set_Height(int ht)
{
	map_height = ht;
}
void Maze_Generator::Set_Width(int wt)
{
	map_width = wt;
}
void Maze_Generator::Delete_Maps()
{
	int ct = 0;
	std::string filename = "../Maps/Map" + std::to_string(ct) + ".txt";
	FILE *fp;
	while ((fp = fopen(filename.c_str(), "r")))
	{
		fclose(fp);

		remove(filename.c_str());
		++ct;
		filename = "../Maps/Map" + std::to_string(ct) + ".txt";
	}
}
void Maze_Generator::Make_Room(int x, int y, int height_given, int check)
{
	//printf("x and y are %d %d\n", x, y);
	if (x < 2)
	{
		x += 2;
	}
	if (y < 2)
	{
		y += 2;
	}
	int height_counter = x, width_counter = y;
	int h = 0, w = 0;
	int xyz = 0;
	int i, j, counter = 1, left_checker = 0, down_checker = 0;
	int height = 0, width = 0;
	int down_counter = 0, left_counter = 0, up_counter = 0;
	//int arr[10000][2];
	i = x;
	j = y;

	while ((map[i][j] != ' ' || up_counter <= 2) && i >= 0 && height < height_given)
	{
		//arr[counter][0] = i;//store row coordinate.
		//arr[counter][1] = j;//store column coordinate.
		map[i][j] = '@';
		--i;
		++counter;
		++height;
		++up_counter;
		++h;
	}
	++i;
	while ((map[i][j] != ' ' || left_counter <= 2) && j >= 0 && width < height_given)//this while loop will backtrack for the hard left.
	{

		//arr[counter][0] = i;//store row coordinate.
		//arr[counter][1] = j;//store column coordinate.
		map[i][j] = '@';
		--j;
		++counter;
		left_counter++;
		width++;
		++w;
	}
	++j;

	while (i <= x && i < map_height)
	{
		//arr[counter][0] = i;
		//arr[counter][1] = j;
		map[i][j] = '@';
		for (int k = j; k < y; k++)
		{
			map[i][k] = '@';
		}
		++i;
		++counter;
	}
	--i;
	while (j != y + 1 && j < map_width)
	{
		//arr[counter][0] = i;
		//arr[counter][1] = j;
		map[i][j] = '@';
		++j;
		++counter;
	}

	//printf("height counter and width counter are %d %d\n", height_counter, width_counter);
	if (check == 0)
	{
		height_counter -= h / 2;
		width_counter -= w / 2;
		if (height_counter < 0)
		{
			height_counter = 0;
		}
		if (width_counter < 0)
		{
			width_counter = 0;
		}
		map[height_counter][width_counter] = global_room_counter;
		Room_Array[global_rooms].room = global_room_counter;
		Room_Array[global_rooms].x = height_counter;
		Room_Array[global_rooms].y = width_counter;
		++global_rooms;
		++global_room_counter;
		--j;
	}
	//itoa(global_room_counter, room_numero, 10);
}

int Maze_Generator::Check_in_room(int x, int y, int h)
{
	//printf("GOT CALLED\n");
	//printf("X and Y are %d %d \n", x, y);
	int i, j;
	bool ans = false;
	int bounding_x = x - h;
	int bounding_y = y - h;
	if (bounding_x < 0)
	{
		bounding_x = 0;
	}
	if (bounding_y < 0)
	{
		bounding_y = 0;
	}
	//printf("bounding_x and bounding_y are %d %d \n", bounding_x, bounding_y);
	for (i = bounding_x; i < bounding_x + (h + 2); ++i)
	{
		//printf("In loop\n");
		for (j = bounding_y; j < bounding_y + (h + 2); ++j)
		{
			if (map[i][j] == '@')
			{
				//printf("returning 1\n");
				return 1;
			}
		}
	}
	return 0;
}

bool Maze_Generator::Valid_Pos(int x, int y)
{
	if (x >= 0 && x < map_height)
	{
		if (y >= 0 && y < map_width)
		{
			return true;
		}
	}
	return false;
}
void Maze_Generator::A_Star(int s_x, int s_y, int g_x, int g_y, int r1_x, int r1_y, int r2_x, int r2_y , int h)
{

	//make att @ walls
	int i, index = 0, j, x, y, x1, y1;
	for (i = 0; i < map_height; ++i)
	{
		for (j = 0; j < map_width; ++j)
		{
			if (map[i][j] == '@')
			{
				map[i][j] = '#';
			}
		}
	}

	Make_Room(r1_x, r1_y, h,1);
	Make_Room(r2_x, r2_y, h,1);
	/*printf("\n\n");
	Print_Map();
	system("pause");*/
	int m = 0, n = 0;
	
	for (i = 0; i < map_height; i++)//initialize the map.
	{
		for (j = 0; j < map_width; j++)
		{
			z.x = i;
			z.y = j;
			a_star_map[i][j] = z;
		}
	}



	int poscheck_row, poscheck_col;
	int diagcheck1_row, diagcheck1_col;
	int diagcheck2_row, diagcheck2_col;
	ElementNode start_;
	ElementNode pointing;

	start_.x = s_x;//storing the values of the first node from the grid to the structure that I am using.
	start_.y = s_y;//same as above.
	start_.parent_x = -1;//start node has no parent.
	start_.parent_y = -1;
	start_.gx = 0.0f;
	arrptr = 1;
	arr[0] = start_;//Storing the first element in the open list.
	start_.isonopenlist = 1;//put start on open list.

	while (arrptr != 0)//while open list is not empty
	{
		/*POP THE CHEAPEST NODE OFF THE LIST*/
		for (i = 0; i < arrptr; ++i)//Find the cheapest node in the Open List
		{
			if (arr[i].cost < arr[index].cost)
			{
				index = i;
			}
		}

		if (g_x == arr[index].x && g_y == arr[index].y)//if the goal is found.
		{
			break;
		}
		arr[index].isonopenlist = 0;//removed from open list.
		//pointing = arr[index];//copy into pointing so we can use this to explore the new neighbors
		x = arr[index].x;
		y = arr[index].y;
		a_star_map[x][y] = arr[index];
		arr[index] = arr[arrptr - 1];//Replace the cheapest element with the last element.
		arrptr--;//decrease size of the list.

		poscheck_row = x + 1;
		poscheck_col = y - 1;


		diagcheck1_row = x + 1;
		diagcheck1_col = y;


		diagcheck2_row = x;
		diagcheck2_col = y - 1;
		//checking first neighbor//
		

		poscheck_row = x + 1;
		poscheck_col = y;
		//checking Second neighbor//
		if (Valid_Pos(poscheck_row, poscheck_col))
		{
			//printf("HAIII FRANZZZ 2\n");
			if (map[poscheck_row][poscheck_col] != '#')
			{
				//printf("NO WALL IN 1\n");
				if (a_star_map[x + 1][y].isonclosedlist == 0 && a_star_map[x + 1][y].isonopenlist == 0)//is on no lists.
				{
					a_star_map[x + 1][y].hx = Octile(x + 1, y, g_x, g_y);//get the value for hx
					//a_star_map[x + 1][y].hx *= weight;
					a_star_map[x + 1][y].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x + 1][y].parent_x = x;
					a_star_map[x + 1][y].parent_y = y;
					a_star_map[x + 1][y].cost = a_star_map[x + 1][y].hx + a_star_map[x + 1][y].gx;
					//arrptr++;
					a_star_map[x + 1][y].isonopenlist = 1;//make the openlist flag = 1 indicating that it is on the open list
					arr[arrptr] = a_star_map[x + 1][y];//push on to the open list.
					arrptr++;


				}
				else if ((a_star_map[x + 1][y].isonclosedlist == 1 || a_star_map[x + 1][y].isonopenlist == 1) && a_star_map[x + 1][y].gx > a_star_map[x][y].gx + 1.0f)
				{
					a_star_map[x + 1][y].hx = Octile(x + 1, y, g_x, g_y);//get the value for hx
					//a_star_map[x + 1][y].hx *= weight;
					a_star_map[x + 1][y].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x + 1][y].parent_x = x;
					a_star_map[x + 1][y].parent_y = y;
					a_star_map[x + 1][y].cost = a_star_map[x + 1][y].hx + a_star_map[x + 1][y].gx;
					if (a_star_map[x + 1][y].isonclosedlist == 1)
					{
						a_star_map[x + 1][y].isonclosedlist == 0;//remove from closed list if it is on the closed list.
						a_star_map[x + 1][y].isonopenlist = 1;//put this on open list
						//arrptr++;
						arr[arrptr] = a_star_map[x + 1][y];//put back on open list.
						arrptr++;

					}
					else if (a_star_map[x + 1][y].isonopenlist == 1)
					{
						//arrptr++;
						for (i = 0; i < arrptr; ++i)//Find the existing node in the open list
						{
							if (arr[i].x == x + 1 && arr[i].y == y)//change the values of the node with the new one
							{
								arr[i] = a_star_map[x + 1][y];
							}
						}
						//coloring.row = x + 1;
						//coloring.col = y;
						//terrain->set_color(coloring, Colors::Blue);
					}
				}
			}
		}

		//checking third neighbor//
		poscheck_row = x + 1;
		poscheck_col = y + 1;


		diagcheck1_row = x + 1;
		diagcheck1_col = y;


		diagcheck2_row = x;
		diagcheck2_col = y + 1;
		

		//checking fourth neighbor//
		poscheck_row = x;
		poscheck_col = y + 1;
		if (Valid_Pos(poscheck_row, poscheck_col))
		{
			//printf("HAIII FRANZZZ 4\n");
			if (map[poscheck_row][poscheck_col] != '#')
			{
				//printf("NO WALL IN 1\n");
				if (a_star_map[x][y + 1].isonclosedlist == 0 && a_star_map[x][y + 1].isonopenlist == 0)//is on no lists.
				{
					a_star_map[x][y + 1].hx = Octile(x, y + 1, g_x, g_y);//get the value for hx
					//a_star_map[x][y + 1].hx *= weight;
					a_star_map[x][y + 1].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x][y + 1].parent_x = x;
					a_star_map[x][y + 1].parent_y = y;
					a_star_map[x][y + 1].cost = a_star_map[x][y + 1].hx + a_star_map[x][y + 1].gx;
					//arrptr++;
					a_star_map[x][y + 1].isonopenlist = 1;//make the openlist flag = 1 indicating that it is on the open list
					arr[arrptr] = a_star_map[x][y + 1];//push on to the open list.
					arrptr++;


				}
				else if ((a_star_map[x][y + 1].isonclosedlist == 1 || a_star_map[x][y + 1].isonopenlist == 1) && a_star_map[x][y + 1].gx > a_star_map[x][y].gx + 1.0f)
				{
					a_star_map[x][y + 1].hx = Octile(x, y + 1, g_x, g_y);//get the value for hx
					//a_star_map[x][y + 1].hx *= weight;
					a_star_map[x][y + 1].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x][y + 1].parent_x = x;
					a_star_map[x][y + 1].parent_y = y;
					a_star_map[x][y + 1].cost = a_star_map[x][y + 1].hx + a_star_map[x][y + 1].gx;
					if (a_star_map[x][y + 1].isonclosedlist == 1)
					{
						a_star_map[x][y + 1].isonclosedlist == 0;//remove from closed list if it is on the closed list.
						a_star_map[x][y + 1].isonopenlist = 1;//put this on open list
						//arrptr++;
						arr[arrptr] = a_star_map[x][y + 1];//put back on open list.
						arrptr++;

					}
					else if (a_star_map[x][y + 1].isonopenlist == 1)
					{
						//arrptr++;
						for (i = 0; i < arrptr; ++i)//Find the existing node in the open list
						{
							if (arr[i].x == a_star_map[x][y + 1].x && arr[i].y == a_star_map[x][y + 1].y)//change the values of the node with the new one
							{
								arr[i] = a_star_map[x][y + 1];
							}
						}
						//coloring.row = x;
						//coloring.col = y + 1;
						//terrain->set_color(coloring, Colors::Blue);
					}
				}
			}
		}

		//checking fifth neighbor//
		poscheck_row = x - 1;
		poscheck_col = y + 1;


		diagcheck1_row = x - 1;
		diagcheck1_col = y;


		diagcheck2_row = x;
		diagcheck2_col = y + 1;
		
		//checking sixth neighbor//
		poscheck_row = x - 1;
		poscheck_col = y;
		if (Valid_Pos(poscheck_row, poscheck_col))
		{
			//printf("HAIII FRANZZZ 6\n");
			if (map[poscheck_row][poscheck_col] != '#')
			{
				//printf("NO WALL IN 1\n");
				if (a_star_map[x - 1][y].isonclosedlist == 0 && a_star_map[x - 1][y].isonopenlist == 0)//is on no lists.
				{
					a_star_map[x - 1][y].hx = Octile(x - 1, y, g_x, g_y);//get the value for hx
					//a_star_map[x - 1][y].hx *= weight;
					a_star_map[x - 1][y].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x - 1][y].parent_x = x;
					a_star_map[x - 1][y].parent_y = y;
					a_star_map[x - 1][y].cost = a_star_map[x - 1][y].hx + a_star_map[x - 1][y].gx;
					//arrptr++;
					a_star_map[x - 1][y].isonopenlist = 1;//make the openlist flag = 1 indicating that it is on the open list
					arr[arrptr] = a_star_map[x - 1][y];//push on to the open list.
					arrptr++;

				}
				else if ((a_star_map[x - 1][y].isonclosedlist == 1 || a_star_map[x - 1][y].isonopenlist == 1) && a_star_map[x - 1][y].gx > a_star_map[x][y].gx + 1.0f)
				{
					a_star_map[x - 1][y].hx = Octile(x - 1, y, g_x, g_y);//get the value for hx
					//a_star_map[x - 1][y].hx *= weight;
					a_star_map[x - 1][y].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x - 1][y].parent_x = x;
					a_star_map[x - 1][y].parent_y = y;
					a_star_map[x - 1][y].cost = a_star_map[x - 1][y].hx + a_star_map[x - 1][y].gx;
					if (a_star_map[x - 1][y].isonclosedlist == 1)
					{
						a_star_map[x - 1][y].isonclosedlist == 0;//remove from closed list if it is on the closed list.
						a_star_map[x - 1][y].isonopenlist = 1;//put this on open list
						//arrptr++;
						arr[arrptr] = a_star_map[x - 1][y];//put back on open list.
						arrptr++;

					}
					else if (a_star_map[x - 1][y].isonopenlist == 1)
					{
						//arrptr++;
						for (i = 0; i < arrptr; ++i)//Find the existing node in the open list
						{
							if (arr[i].x == a_star_map[x - 1][y].x && arr[i].y == a_star_map[x - 1][y].y)//change the values of the node with the new one
							{
								arr[i] = a_star_map[x - 1][y];
							}
						}
						//coloring.row = x - 1;
						//coloring.col = y;
						//terrain->set_color(coloring, Colors::Blue);
					}
				}
			}
		}

		//checking seventh neighbor//
		poscheck_row = x - 1;
		poscheck_col = y - 1;


		diagcheck1_row = x - 1;
		diagcheck1_col = y;


		diagcheck2_row = x;
		diagcheck2_col = y - 1;
		
		//checking eight neighbor//
		poscheck_row = x;
		poscheck_col = y - 1;
		if (Valid_Pos(poscheck_row, poscheck_col))
		{
			//printf("HAIII FRANZZZ 8\n");
			if (map[poscheck_row][poscheck_col] != '#')
			{
				//printf("NO WALL IN 1\n");
				if (a_star_map[x][y - 1].isonclosedlist == 0 && a_star_map[x][y - 1].isonopenlist == 0)//is on no lists.
				{
					a_star_map[x][y - 1].hx = Octile(x, y - 1, g_x, g_y);//get the value for hx
					//a_star_map[x][y - 1].hx *= weight;
					a_star_map[x][y - 1].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x][y - 1].parent_x = x;
					a_star_map[x][y - 1].parent_y = y;
					a_star_map[x][y - 1].cost = a_star_map[x][y - 1].hx + a_star_map[x][y - 1].gx;
					//arrptr++;
					a_star_map[x][y - 1].isonopenlist = 1;//make the openlist flag = 1 indicating that it is on the open list
					arr[arrptr] = a_star_map[x][y - 1];//push on to the open list.
					arrptr++;

				}
				else if ((a_star_map[x][y - 1].isonclosedlist == 1 || a_star_map[x][y - 1].isonopenlist == 1) && a_star_map[x][y - 1].gx > a_star_map[x][y].gx + 1.0f)
				{
					a_star_map[x][y - 1].hx = Octile(x, y - 1, g_x, g_y);//get the value for hx
					//a_star_map[x][y - 1].hx *= weight;
					a_star_map[x][y - 1].gx = a_star_map[x][y].gx + 1.0f;//get the distance via the paretn from the start node
					a_star_map[x][y - 1].parent_x = x;
					a_star_map[x][y - 1].parent_y = y;
					a_star_map[x][y - 1].cost = a_star_map[x][y - 1].hx + a_star_map[x][y - 1].gx;
					if (a_star_map[x][y - 1].isonclosedlist == 1)
					{
						a_star_map[x][y - 1].isonclosedlist == 0;//remove from closed list if it is on the closed list.
						a_star_map[x][y - 1].isonopenlist = 1;//put this on open list
						//arrptr++;
						arr[arrptr] = a_star_map[x][y - 1];//put back on open list.
						arrptr++;

					}
					else if (a_star_map[x][y - 1].isonopenlist == 1)
					{
						//arrptr++;
						for (i = 0; i < arrptr; ++i)//Find the existing node in the open list
						{
							if (arr[i].x == a_star_map[x][y - 1].x && arr[i].y == a_star_map[x][y - 1].y)//change the values of the node with the new one
							{
								arr[i] = a_star_map[x][y - 1];
							}
						}
						//coloring.row = x;
						//coloring.col = y - 1;
						//terrain->set_color(coloring, Colors::Blue);
					}
				}
			}
		}
		index = 0;
		a_star_map[x][y].isonclosedlist = 1;//put this on closed list
	}
	//printf("the goal values are %d %d\n", arr[index].x, arr[index].y);
	//system("pause");
	int gobacc_row, gobacc_col;
	gobacc_row = arr[index].x;
	gobacc_col = arr[index].y;
	ElementNode gobacc1=arr[index];
	//int patharr[10000][2],arrsize;
	while (gobacc_row != -1 && gobacc_col != -1)
	{
		//system("pause");
		//We will store all the nodes in an array first
		x = gobacc1.parent_x;
		y = gobacc1.parent_y;
		gobacc1 = a_star_map[x][y];
		gobacc_row = x;
		gobacc_col = y;
		map[x][y] = '~';
		//printf("current x and y are : %d %d \n", x, y);
	}
}
int main()
{

	int at_check = 1;
	int wall_x = 0, wall_y = 0;
	int rooms = 1, rctr = 0;
	srand(time(0));
	int sm = 0;
	float branchrate = 0.0f;//this decides if there will be a biased or an unbaised branching of the maze. (unique path from point a to point b)
	//zero is unbiased, positive will make branches more frequent, negative will cause long passages. Positive leans towards start and 
	//negative will give us longer corridors as it is leaning towards the end. Try values between -10 and +10.
	printf("wanna delete previous maps? Y : Yes/N : No\n");
	char c = 'Y', chomu; char c1[] = { 'Y' };
	bool cont = true;
	c = getchar();
	if (c == 'Y')
	{
		cout << "Maps were deleted :D !!" << endl;
		Maze_Generator tobj;
		tobj.Delete_Maps();
	}
	else
	{
		cout << "Either nothing was deleted or you enetered no!!" << endl;
	}
	int mp = 0, m, ctr = 0, h;
	int width, height;
	while (c1[0] == 'Y')
	{
		printf("enter the Branchrate, please keep it between -10 and +10: \n");
		printf("-10 will give you longer corridors and +10 will give you better branching. 0 is unbiased. \n");
		scanf("%f", &branchrate);
		printf("enter the number of maps to be generated:");
		scanf("%d", &m);
		mp += m;//increment if you want to create more maps.
		printf("enter map width\n");
		scanf("%d", &width);
		printf("enter map height\n");
		scanf("%d", &height);
		printf("enter the number of rooms you want in the map and the dimension coefficient\n");
		scanf("%d %d", &rooms, &h);
		while (ctr < mp)
		{
			float e = 2.71828182846;
			Maze_Generator obj;
			obj.Set_Height(height);//Makee 1.
			obj.Set_Width(width);
			obj.Map_Initializer();
			obj.Print_Map();
			printf("\n\n");
			system("pause");
			//obj.Save_Map(sm);
			//obj.Save_Map1(sm);
			++sm;
			int x = rand();
			int y = rand();
			x %= obj.map_height;
			y %= obj.map_width;
			//cout <<"X is: " <<x << ", Y is: " << y << endl;
			obj.Set_Space(x, y);

			int i = 0, j;
			int p;

			int choice_x, choice_y;

			while (obj.fct >= 0)
			{
				float pos = obj.Get_Radn();
				//cout << "number of elements in the DAMN frontier are "<< obj.fct << endl;
				//system("pause");
				pos = pos / (RAND_MAX);
				pos = pow(pos, (pow(e, branchrate)));
				//cout << "pos factor is: " << pos << endl;
				int pt = pos * obj.fct;//multiply by the length to pick an element.
				//cout << "point on frontier array is "<<pt << endl;
				choice_x = obj.frontier[pt][0];
				choice_y = obj.frontier[pt][1];
				if (obj.Scan(choice_x, choice_y))
				{
					//printf("true at %d %d\n", choice_x, choice_y);
					obj.Set_Space(choice_x, choice_y);
				}
				else
				{
					//printf("false at %d %d\n", choice_x, choice_y);
					obj.Make_Wall(choice_x, choice_y);
				}
				for (j = pt; j < obj.fct - 1; ++j)//remove the used point.
				{
					obj.frontier[j][0] = obj.frontier[j + 1][0];
					obj.frontier[j][1] = obj.frontier[j + 1][1];
				}
				obj.fct--;
				++i;
			}
			for (i = 0; i < obj.map_height; ++i)
			{
				for (j = 0; j < obj.map_width; ++j)
				{
					if (obj.map[i][j] == '?')
					{
						obj.map[i][j] = '#';
					}
				}
			}
			obj.Print_Map();
			printf("\n\n");
			system("pause");
			obj.Save_Map(sm);
			obj.Save_Map1(sm);
			++sm;
			//----------------------------------------------------------------------------

			int wall_arr[100][2], wall_counter = 0;
			int wall_x;
			int wall_y;
			int done_gone = 0;
			do//do this till we find a valid '#'
			{
				//obj.map[wall_x][wall_y] = 1
				wall_x = obj.Get_Radn();
				wall_y = obj.Get_Radn();

				wall_x %= obj.map_height;
				wall_y %= obj.map_width;

			} while (obj.map[wall_x][wall_y] != '#');
			//system("pause");
			obj.Make_Room(wall_x, wall_y, h,0);//calling the function to make a room~
			wall_arr[wall_counter][0] = wall_x;
			wall_arr[wall_counter][1] = wall_y;
			++wall_counter;
			//obj.Print_Map();





			clock_t start = clock();//start timer
			
			while (rctr < rooms - 1)
			{
				while (obj.map[wall_x][wall_y] != '#' || at_check == 1)
				{

					wall_x = obj.Get_Radn();
					wall_y = obj.Get_Radn();

					wall_x %= obj.map_height;
					wall_y %= obj.map_width;
					at_check = obj.Check_in_room(wall_x, wall_y, h);
					clock_t elapsed_time = clock();
					double elapsed = (double)(elapsed_time - start) * 1000.0 / CLOCKS_PER_SEC;
					if (elapsed > 2000)
					{
						done_gone = 1;
						break;

					}
				}

				//printf("wall_x and wall_y are: %d %d \n", wall_x, wall_y);

				//system("pause");
				if (done_gone != 1)
				{
					wall_arr[wall_counter][0] = wall_x;
					wall_arr[wall_counter][1] = wall_y;
					++wall_counter;
					obj.Make_Room(wall_x, wall_y, h,0);//calling the function to make a room~
				}
				//obj.Print_Map();
				rctr++;
			}
			/*for (int i = 0; i < global_rooms; i++)
			{
				cout << "Room: " << Room_Array[i].room << endl;
				cout << "X: " << Room_Array[i].x << endl;
				cout << "Y: " << Room_Array[i].y << endl;
				cout << "Found? (1 for yes and 0 for no): " << Room_Array[i].found << endl;
				cout << "--------------------" << endl;
			}*/
			obj.Print_Map();
			printf("\n\n");
			system("pause");
			obj.Save_Map1(sm);
			obj.Save_Map(sm);
			++sm;
			global_room_counter = 'A';
			
			for (j = 0; j < global_rooms; ++j)
			{
				for (int i = j; i < global_rooms; ++i)
				{
					if (i != j)
					{
						obj.A_Star(Room_Array[j].x, Room_Array[j].y, Room_Array[i].x, Room_Array[i].y, wall_arr[j][0], wall_arr[j][1], wall_arr[i][0], wall_arr[i][1], h);
						obj.map[Room_Array[j].x][Room_Array[j].y] = Room_Array[j].room;
						/*obj.Make_Room(Room_Array[j].x, Room_Array[j].y, h);
						obj.Make_Room(Room_Array[i].x, Room_Array[i].y, h);*/
					}
				}
			}
			
			for (int i = 0; i < wall_counter; ++i)
			{
				obj.Make_Room(wall_arr[i][0], wall_arr[i][1], h,0);
			}
			cout << endl;
			
			obj.Save_Map(sm);
			
			for (i = 0; i < obj.map_height; ++i)
			{
				for (j = 0; j < obj.map_width; ++j)
				{
					if (obj.map[i][j] == ' ')
					{
						obj.map[i][j] = '#';
					}
				}
			}
			obj.Print_Map();
			printf("\n\n");
			system("pause");
			for (i = 0; i < obj.map_height; ++i)
			{
				for (j = 0; j < obj.map_width; ++j)
				{
					if (obj.map[i][j] == '~')
					{
						obj.map[i][j] = ' ';
					}
				}
			}
			obj.Save_Map1(sm);
			++sm;
			for (i = 0; i < obj.map_height; ++i)
			{
				for (j = 0; j < obj.map_width; ++j)
				{
					if (obj.map[i][j] == '@')
					{
						obj.map[i][j] = ' ';
					}
				}
			}
			obj.Print_Map();
			printf("\n\n");
			system("pause");
			obj.Save_Map(sm);
			obj.Save_Map1(sm);
			++sm;
			rctr = 0;
			
			global_rooms = 0;
			++ctr;
			wall_counter = 0;
		}
		
		global_room_counter = 'A';
		printf("Do you wanna continue? : Y:YES/N:No\n");
		scanf("%s", &chomu);
		c1[0] = chomu;
		if (c1[0] == 'Y')
		{
			cont = true;
		}
		else
		{
			cont = false;
		}

	}
	system("pause");
	return 0;
}
